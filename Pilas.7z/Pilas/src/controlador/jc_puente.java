/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.RenderingHints.Key;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import vistas.jd_vista_datos;

/**
 *
 * @author alumno
 */
public class jc_puente implements KeyListener{
    jd_vista_datos vista = new jd_vista_datos(null, true);
    //Vector datos = new Vector();
    DefaultTableModel valores = new DefaultTableModel();
    public jc_puente(jd_vista_datos vista2){
        this.vista=vista2;
        this.vista.jTextField1.addKeyListener(this); //para que se quede escuchando desde el constructor
        valores.addColumn("Datos");
    }
    public void keyReleased(KeyEvent key){
        
    }
    public void keyPressed(KeyEvent key2){
        if (key2.VK_ENTER == key2.getKeyChar()){
            //JOptionPane.showMessageDialog(vista, "si funciona");
            Vector datos = new Vector();
            datos.addElement(vista.jTextField1.getText());
            valores.addRow(datos);
            vista.jTable1.setModel(valores);
        }
    }
    public void keyTyped(KeyEvent key3){
        
    }
}
