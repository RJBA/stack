
import controlador.jc_puente;
import vistas.jd_vista_datos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alumno
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        jd_vista_datos vista = new jd_vista_datos(null, true);
        jc_puente puente = new jc_puente(vista);
        vista.setVisible(true);
        vista.setLocationRelativeTo(null);
    }
    
}
